package com.backend3.project3.RoadReady3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoadReady3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
