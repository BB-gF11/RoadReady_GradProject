package com.backend3.project3.RoadReady3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoadReady3Application {

    public static void main(String[] args) {
        SpringApplication.run(RoadReady3Application.class, args);
    }
}
